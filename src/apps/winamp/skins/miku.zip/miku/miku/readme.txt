"Concealed Night"
-Miku Hinasaki
-Fatal Frame I
-8/11/04

{milgasia@hotmail.com}

CHRYSALIS
<http://draconic.gemna.net/chrysalis>

The second in my skin tribute to Tecmo's wonderful FATAL FRAME games. This features the heroine from Fatal Frame I, Miku. For those who don't know, she's the photo snapping teenage girl in a schoolgirl outfit running around in a dark haunted manion looking for her hot brother and fighting ghosts. Whoo!

I adored this picture the moment I saw it (particularly the cloth behind Miku) and this may be the most visually pleasing skin I've made for awhile (Miku looks so pretty there~). And this is one of the rare times I actually LIKE the playlist. And I hope you do too, I think it's pretty^^ And if you DON'T like it - I'll sick the Blinded ghosts to haunt you >=P

I hope to make more Fatal Frame skins soon. I've been in a rut lately, so we'll see if I pick back up *crosses fingers*

The song is a pretty song by chinese singer Faye Wong. I'm not entirely show what she's singing because my Chinese skills went downhill... but I just like how the title sounds.

Enjoy!.. and shameless plug: visit Beyond the Camera's Lens! <http://www.cameraslens.com> Emi's supah cool~! And she affiliated me! Whee^^

Mil
